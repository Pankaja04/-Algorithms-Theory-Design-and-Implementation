//Student id:-20210227
//Name:- Shehan Amantha Senevirathne

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Graph {
    private final int V; // Number of vertices
    private final List<List<Integer>> adjacencylist; // Adjacency list

    public Graph(int V) {
        this.V = V;
        adjacencylist = new ArrayList<>(V);
        for (int i = 0; i < V; i++) {
            adjacencylist.add(new ArrayList<>());
        }
    }

    // Add edge to the graph
    public void addedges(int v, int w) {
        adjacencylist.get(v).add(w);
    }

    // Remove edge from the graph
    public void removeEdges(int v, int w) {
        adjacencylist.get(v).remove(Integer.valueOf(w));
    }

    // Find a sink  in the graph
    public int find_Sink() {
        boolean[] Outgoing = new boolean[V];
        for (int v = 0; v < V; v++) {
            for (int w : adjacencylist.get(v)) {
                Outgoing[v] = true;
            }
        }
        for (int v = 0; v < V; v++) {
            if (!Outgoing[v]) {
                return v;
            }
        }
        return -1; // if no sink found
    }

    // Sink Elimination Algorithm
    public boolean Acyclic() {
        int sink;
        while ((sink = find_Sink()) != -1) {
            System.out.println("Eliminated sink: " + sink);
            for (int w : adjacencylist.get(sink)) {
                removeEdges(sink, w);
            }
        }
        return adjacencylist.stream().noneMatch(list -> !list.isEmpty());
    }

    // Depth-First Search
    public List<Integer> findcycle() {
        boolean[] visited = new boolean[V];
        boolean[] recursionStack = new boolean[V];
        List<Integer> cycle = new ArrayList<>();
        for (int v = 0; v < V; v++) {
            if (!visited[v] && findCycleExtnd(v, visited, recursionStack, cycle)) {
                Collections.reverse(cycle);
                return cycle;
            }
        }
        return null; // if no cycle found
    }

    // findCycle method extended
    private boolean findCycleExtnd(int v, boolean[] visited, boolean[] recursionStack, List<Integer> cycle) {
        visited[v] = true;
        recursionStack[v] = true;
        for (int w : adjacencylist.get(v)) {
            if (!visited[w] && findCycleExtnd(w, visited, recursionStack, cycle)) {
                cycle.add(w);
                return true;
            } else if (recursionStack[w]) {
                cycle.add(w);
                return true;
            }
        }
        recursionStack[v] = false;
        return false;
    }

    public static void main(String[] args) throws FileNotFoundException {
        // Read input file
        Scanner scanner = new Scanner(new File("input.txt"));
        int V = scanner.nextInt();
        Graph graph = new Graph(V);
        while (scanner.hasNextInt()) {
            int v = scanner.nextInt();
            int w = scanner.nextInt();
            graph.addedges(v, w);
        }
        scanner.close();

        // Check if the graph is acyclic
        if (graph.Acyclic()) {
            System.out.println("The graph is acyclic.");
        } else {
            System.out.println("The graph is not acyclic. Cycle: " + graph.findcycle());
        }
    }
}
